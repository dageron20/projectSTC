import React from "react";

const Messages = () => {
    return (
        <aside className="list-users">
            <div>
                <h1>Входящие сообщения</h1>
            </div>
        </aside>
    )
}

export default Messages;